// MPI Find Maximum
#include <mpi.h>
#include <iostream>
using namespace std;

int main(int argc,char* argv[]){
    MPI_Init(&argc,&argv);

    int rank, max;
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);

    int value = rank * 3;
    MPI_Reduce(&value,&max,1,MPI_INT,MPI_MAX,0,MPI_COMM_WORLD);

    if(rank == 0)
        cout << "Max = " << max;

    MPI_Finalize();
}


