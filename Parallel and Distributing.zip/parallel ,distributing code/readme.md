Parallel Computing
 1. Compile : g++ -fopenmp parallel_code1.cpp -o parallel_code1
 2. Run : ./parallel_code1.exe

 Disributed Computing
 1. Compile : & "C:\Program Files\Microsoft MPI\Bin\mpiexec.exe" -n 4 ./distributed_code1.exe
 2. Run : mpiexec -n 2 distributed_code1.exe

 Thread
  1. Compile : g++ code45.cpp -o code45
 2. Run : ./code45.exe

Thread_mutex
  1. Compile : g++ thread_mutex.cpp -o thread_mutex
 2. Run : ./thread_mutex.exe