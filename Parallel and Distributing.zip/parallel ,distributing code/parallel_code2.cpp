// Parallel Sum of Array
#include <iostream>
#include <omp.h>
using namespace std;

int main() {
    int sum = 0;
    int a[5] = {1,2,3,4,5};

    #pragma omp parallel for reduction(+:sum)
    for(int i=0;i<5;i++)
        sum += a[i];

    cout << "Sum = " << sum;
    return 0;
}