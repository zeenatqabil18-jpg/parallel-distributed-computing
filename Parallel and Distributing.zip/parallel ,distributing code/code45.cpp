#include <iostream>
#include <thread>
#include <vector>

using namespace std;

void partial_sum(int start, int end, vector<int>& arr, int &result) {
    for (int i = start; i < end; i++)
        result += arr[i];
}

int main() {
    vector<int> arr = {1,2,3,4,5,6,7,8};
    int result1 = 0, result2 = 0;

    thread t1(partial_sum, 0, 4, ref(arr), ref(result1));
    thread t2(partial_sum, 4, 8, ref(arr), ref(result2));

    t1.join();
    t2.join();

    cout << "Total Sum = " << result1 + result2 << endl;
    return 0;
}
