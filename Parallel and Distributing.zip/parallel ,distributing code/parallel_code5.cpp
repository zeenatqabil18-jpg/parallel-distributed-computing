// Parallel Maximum Element
#include <iostream>
#include <omp.h>
using namespace std;

int main() {
    int a[6] = {4,9,1,7,3,8};
    int max = a[0];

    #pragma omp parallel for reduction(max:max)
    for(int i=0;i<6;i++)
        if(a[i] > max)
            max = a[i];

    cout << "Max = " << max;
}
