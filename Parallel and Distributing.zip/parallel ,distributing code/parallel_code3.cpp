//Parallel Even–Odd Count
#include <iostream>
#include <omp.h>
using namespace std;

int main() {
    int even = 0, odd = 0;

    #pragma omp parallel for
    for(int i=1;i<=10;i++) {
        if(i % 2 == 0)
            #pragma omp atomic
            even++;
        else
            #pragma omp atomic
            odd++;
    }

    cout << "Even: " << even << " Odd: " << odd;
}